# M-Line Logistics Executive Dashboard — Phase-by-Phase Build Instructions

## Purpose

Build and refine the **Executive Overview Dashboard** for the M-Line Logistics Google Apps Script system.

The dashboard should show operational performance, financial performance, cash position, receivables, payables, expenses, and other income using a clean HTML dashboard UI.

The dashboard should **not rely on spreadsheet formulas for calculations**. All calculations should live inside Apps Script code. The `Dashboard_Helper` sheet should only act as a calculated output/cache layer for KPI values and chart source tables.

---

# Global Rules

## 1. Calculation ownership

All dashboard calculations must be handled inside Apps Script.

Do not place heavy formulas in:

- `Executive Overview`
- `Dashboard_Helper`
- Any visible dashboard sheet

The correct flow is:

```text
User clicks dashboard refresh/menu/button
↓
Apps Script reads source tables
↓
Apps Script calculates all KPI and chart values in memory
↓
Apps Script writes final output tables to Dashboard_Helper
↓
Dashboard UI/cards/charts read from Dashboard_Helper or returned calculated payload
```

## 2. Dashboard_Helper purpose

`Dashboard_Helper` is only an output/cache sheet.

It should store:

- KPI values
- Chart source tables
- Filter state
- Viewing label
- Dashboard end date
- Last refreshed timestamp

It should not contain business logic formulas.

## 3. Metric classification

Use this rule:

```text
Performance metrics follow the selected period.
Balance metrics are calculated as of the selected period end date.
```

### Performance metrics

These follow the selected period:

- Total Trips
- Own Truck Trips
- Subcon Trips
- Total Revenue
- Total Cost
- Net Income
- Trips by Month
- Monthly Financial Performance
- OPEX Breakdown
- Other Income Breakdown
- Net Cash Flow

### Balance metrics

These are calculated **as of dashboardEndDate**:

- Receivables
- Payables
- Current Balance
- Receivables donut
- Payables donut

---

# Phase 1 — Confirm source tables and required fields

## Goal

Map the dashboard to the existing system tables and confirm that all required fields exist.

## Source tables

Use these source tables/sheets:

### TripsDB

Required fields:

- `Trip ID`
- `Delivery Date`
- `Subcon?`
- `grossEarnings` or `Gross Earnings`
- `Total Subcon Earnings`
- `Billing Status`
- `Payment Date`
- `Subcon Payable Status`
- `Subcon Payment Ref`
- `Posted At`

### Expenses

Required fields:

- `Date`
- `Category`
- `Particulars`
- `Amount`
- `Remarks`

### OtherIncome

Required fields:

- `Date`
- `Category`
- `Particulars`
- `Amount`
- `Remarks`

### CashFlow

Required fields:

- `Date`
- `Cash In`
- `Cash Out`
- `Particulars`
- `Remarks`

### Settings / Cash Flow Summary

Required value:

- Opening Balance

## Phase 1 output

Create or confirm a field map object in code.

Implementation status:

- Dashboard source table keys, the lazy dashboard field map, and source validation helpers live in `dashboard/Config.js`.
- `loadDashboardSourceData_()` validates the dashboard source config and required source headers before reading dashboard records.
- Opening Balance is read from `APP_SETTINGS.dashboardOpeningBalanceRange`.

Example:

```js
const DASHBOARD_FIELD_MAP = {
  trips: {
    tripId: 'Trip ID',
    deliveryDate: 'Delivery Date',
    isSubcon: 'Subcon?',
    grossEarnings: 'Gross Earnings',
    subconEarnings: 'Total Subcon Earnings',
    billingStatus: 'Billing Status',
    paymentDate: 'Payment Date',
    subconPayableStatus: 'Subcon Payable Status'
  },
  expenses: {
    date: 'Date',
    category: 'Category',
    amount: 'Amount'
  },
  otherIncome: {
    date: 'Date',
    category: 'Category',
    amount: 'Amount'
  },
  cashFlow: {
    date: 'Date',
    cashIn: 'Cash In',
    cashOut: 'Cash Out'
  }
};
```

---

# Phase 2 — Build dashboard filter model

## Goal

Support clean filtering with `All` options and a visible viewing label.

Implementation status:

- `resolveDashboardFilter_()` accepts omitted filters for the existing latest-period default and explicit `All` filters for Lifetime mode.
- The dashboard payload returns `controls.viewingLabel`, normalized filter values, `periodStartDate`, `periodEndDate`, and `dashboardEndDate`.
- The dialog header includes the viewing label, Year/Month `All` options, and a Clear button.
- If Year is `All`, Month is forced to `All` and disabled in the dialog.

## Filter controls

Use these filter controls in the dashboard header:

```text
Year:  [All / 2025 / 2026 / 2027]
Month: [All / Jan / Feb / Mar / ... / Dec]
[Clear] [Refresh]
```

## Viewing label

Show a small label beside the filters:

```text
Viewing: Jun 2026
```

or:

```text
Viewing: 2026
```

or:

```text
Viewing: Lifetime
```

## Year dropdown values

The year list should be generated from available source data, not hardcoded.

Use dates from:

- `TripsDB[Delivery Date]`
- `Expenses[Date]`
- `OtherIncome[Date]`
- `CashFlow[Date]`

Always include:

```text
All
```

## Month dropdown values

Use:

```text
All, Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec
```

## Filter behavior

### Case 1 — Year and Month selected

Example:

```text
Year = 2026
Month = Jun
```

Use:

```text
periodStartDate = June 1, 2026
periodEndDate = June 30, 2026
viewingLabel = Viewing: Jun 2026
```

### Case 2 — Year selected, Month = All

Example:

```text
Year = 2026
Month = All
```

Use:

```text
periodStartDate = Jan 1, 2026
periodEndDate = latest available source date within 2026
viewingLabel = Viewing: 2026
```

Do not automatically use Dec 31 if the year is not complete.

### Case 3 — Year = All, Month = All

Use:

```text
periodStartDate = earliest available source date
periodEndDate = latest available source date
viewingLabel = Viewing: Lifetime
```

### Case 4 — Year = All, Month selected

Do not allow this mode.

If `Year = All`, force `Month = All` or disable the Month dropdown.

## Clear button

The Clear button should set:

```text
Year = All
Month = All
```

Then refresh the dashboard.

---

# Phase 3 — Define dashboard date scopes

## Goal

Separate selected-period calculations from as-of balance calculations.

Implementation status:

- `calculateDashboard_()` uses `dashboardFilter.periodStartDate` and `dashboardFilter.periodEndDate` for performance metrics.
- Receivables and Payables use `dashboardFilter.dashboardEndDate` and include trips with `Delivery Date <= dashboardEndDate`.
- Current Balance already uses `dashboardFilter.dashboardEndDate` for as-of cash balance.

## Period scope

Used by performance metrics.

```text
periodStartDate <= recordDate <= periodEndDate
```

## Dashboard end date

Used by balance metrics.

```text
dashboardEndDate = periodEndDate
```

For lifetime mode:

```text
dashboardEndDate = latest available source date
```

## Balance metric scope

Used by Receivables, Payables, and Current Balance.

```text
recordDate <= dashboardEndDate
```

---

# Phase 4 — Calculate KPI cards

## Goal

Create the 10 executive KPI cards.

## Final KPI cards

1. Total Trips
2. Own Truck Trips
3. Subcon Trips
4. Total Revenue
5. Total Cost
6. Net Income
7. Receivables
8. Payables
9. Net Cash Flow
10. Current Balance

---

## KPI 1 — Total Trips

Classification: Performance metric

```text
Total Trips = count Trip ID where Delivery Date is within selected period
```

---

## KPI 2 — Own Truck Trips

Classification: Performance metric

```text
Own Truck Trips = count Trip ID where:
Delivery Date is within selected period
AND Subcon? is not TRUE
```

Treat blank, `FALSE`, `No`, and false-like values as own truck.

---

## KPI 3 — Subcon Trips

Classification: Performance metric

```text
Subcon Trips = count Trip ID where:
Delivery Date is within selected period
AND Subcon? is TRUE
```

Treat `TRUE`, `Yes`, and true-like values as subcon.

---

## KPI 4 — Total Revenue

Classification: Performance metric

```text
Total Revenue = Trip Revenue + Other Income
```

Where:

```text
Trip Revenue = sum TripsDB[grossEarnings] within selected period
Other Income = sum OtherIncome[Amount] within selected period
```

Important:

```text
grossEarnings = Trip Earnings + Fuel Subsidy
```

---

## KPI 5 — Total Cost

Classification: Performance metric

```text
Total Cost = Subcon Cost + Expenses
```

Where:

```text
Subcon Cost = sum TripsDB[Total Subcon Earnings] where Subcon? = TRUE within selected period
Expenses = sum Expenses[Amount] within selected period
```

---

## KPI 6 — Net Income

Classification: Performance metric

```text
Net Income = Total Revenue - Total Cost
```

Do not call this Gross Profit because Other Income and Expenses are included.

---

## KPI 7 — Receivables

Classification: Balance metric

```text
Receivables = sum TripsDB[grossEarnings] where:
Billing Status is UNBILLED or BILLED
AND Delivery Date <= dashboardEndDate
```

Do not limit Receivables only to the selected month.

Reason:

```text
Receivables are an outstanding balance position, not period-only activity.
```

---

## KPI 8 — Payables

Classification: Balance metric

```text
Payables = sum TripsDB[Total Subcon Earnings] where:
Subcon? = TRUE
AND Subcon Payable Status = UNPAID
AND Delivery Date <= dashboardEndDate
```

Do not limit Payables only to the selected month.

Reason:

```text
Payables are an outstanding liability position, not period-only activity.
```

---

## KPI 9 — Net Cash Flow

Classification: Performance metric

```text
Net Cash Flow = Cash In - Cash Out within selected period
```

Recommended cash-in components:

```text
Collected trip billings during selected period
+ OtherIncome during selected period
+ Manual Cash In during selected period
```

Recommended cash-out components:

```text
Subcon payments during selected period
+ Expenses during selected period
+ Manual Cash Out during selected period
```

If there is no reliable Subcon Payment Date yet, use the current available payment/status logic temporarily and mark this as a known limitation.

---

## KPI 10 — Current Balance

Classification: Balance metric

```text
Current Balance = Opening Balance + all Cash In up to dashboardEndDate - all Cash Out up to dashboardEndDate
```

This should be calculated as an as-of balance.

---

# Phase 5 — Calculate Chart 1: Trips by Month

## Goal

Create a stacked column chart showing own truck trips and subcon trips by month.

## Chart type

```text
Stacked column chart
```

## Chart title

```text
Trips by Month
```

## Series

- Own Truck Trips
- Subcon Trips

## Total count display

The chart should still allow the user to see the total monthly trips.

Recommended options:

1. Use stacked columns where total height = total trips.
2. Show data labels if supported.
3. Store `Total Trips` as a helper/audit column but do not add it as a third stacked series.

## Selected year mode

If a specific year is selected:

```text
Rows = Jan to Dec of selected year
```

Calculation per month:

```text
Own Truck Trips = count trips where:
YEAR(Delivery Date) = selectedYear
MONTH(Delivery Date) = monthNumber
AND Subcon? is not TRUE

Subcon Trips = count trips where:
YEAR(Delivery Date) = selectedYear
MONTH(Delivery Date) = monthNumber
AND Subcon? is TRUE

Total Trips = Own Truck Trips + Subcon Trips
```

## Lifetime mode

If Year = All and Month = All:

```text
Rows = monthly buckets from earliest source month to latest source month
```

Example:

```text
Jan 2025
Feb 2025
Mar 2025
...
Jun 2026
```

If too many months exist later, this can be capped to the latest 12 or 24 months, but do not cap it in the first version unless requested.

## Helper table shape

```text
Month | Own Truck Trips | Subcon Trips | Total Trips
Jan   | 10              | 3            | 13
Feb   | 8               | 4            | 12
```

---

# Phase 6 — Calculate Chart 2: Monthly Financial Performance

## Goal

Show total revenue, total cost, and net income by month.

## Chart title

```text
Monthly Financial Performance
```

## Recommended chart type

Use a combo chart if supported:

- Column/bar: Total Revenue
- Column/bar: Total Cost
- Line: Net Income

If combo chart is not supported in the current HTML chart library, use a grouped column chart with three series.

## Series

1. Total Revenue
2. Total Cost
3. Net Income

## Calculations

### Total Revenue

```text
Total Revenue = Trip Revenue + Other Income
```

Where:

```text
Trip Revenue = sum TripsDB[grossEarnings]
Other Income = sum OtherIncome[Amount]
```

### Total Cost

```text
Total Cost = Subcon Cost + Expenses
```

Where:

```text
Subcon Cost = sum TripsDB[Total Subcon Earnings] where Subcon? = TRUE
Expenses = sum Expenses[Amount]
```

### Net Income

```text
Net Income = Total Revenue - Total Cost
```

## Selected year mode

If a specific year is selected:

```text
Rows = Jan to Dec of selected year
```

## Lifetime mode

If Year = All and Month = All:

```text
Rows = monthly buckets from earliest source month to latest source month
```

## Helper table shape

```text
Month | Total Revenue | Total Cost | Net Income
Jan   | 100000        | 60000      | 40000
Feb   | 120000        | 70000      | 50000
```

---

# Phase 7 — Calculate Chart 3: Receivables donut

## Goal

Show billing status distribution and outstanding receivables as of the dashboard end date.

## Chart title

```text
Receivables Status
```

## Chart type

```text
Donut chart
```

## Scope

This is a balance/status chart.

Use:

```text
Delivery Date <= dashboardEndDate
```

Do not limit this only to the selected period.

## Segments

- UNBILLED
- BILLED
- PAID

## Segment calculations

```text
UNBILLED = sum TripsDB[grossEarnings] where Billing Status = UNBILLED and Delivery Date <= dashboardEndDate
BILLED = sum TripsDB[grossEarnings] where Billing Status = BILLED and Delivery Date <= dashboardEndDate
PAID = sum TripsDB[grossEarnings] where Billing Status = PAID and Delivery Date <= dashboardEndDate
```

## Center value

```text
Receivables = UNBILLED + BILLED
```

Do not include PAID in the center value.

Reason:

```text
Paid revenue is already collected and is no longer receivable.
```

## Center label

```text
RECEIVABLES
```

## Helper table shape

```text
Status   | Amount
UNBILLED | 10000
BILLED   | 5000
PAID     | 20000
```

Also store:

```text
Center Label | Center Value
RECEIVABLES  | 15000
```

---

# Phase 8 — Calculate Chart 4: Payables donut

## Goal

Show subcontractor payment status and outstanding payables as of the dashboard end date.

## Chart title

```text
Payables Status
```

## Chart type

```text
Donut chart
```

## Scope

This is a balance/status chart.

Use:

```text
Delivery Date <= dashboardEndDate
```

Do not limit this only to the selected period.

## Segments

- UNPAID
- PAID

## Segment calculations

```text
UNPAID = sum TripsDB[Total Subcon Earnings] where:
Subcon? = TRUE
AND Subcon Payable Status = UNPAID
AND Delivery Date <= dashboardEndDate

PAID = sum TripsDB[Total Subcon Earnings] where:
Subcon? = TRUE
AND Subcon Payable Status = PAID
AND Delivery Date <= dashboardEndDate
```

## Center value

```text
Payables = UNPAID
```

Do not include PAID in the center value.

Reason:

```text
Paid subcontractor cost is already settled and is no longer payable.
```

## Center label

```text
PAYABLES
```

## Helper table shape

```text
Status | Amount
UNPAID | 10000
PAID   | 5000
```

Also store:

```text
Center Label | Center Value
PAYABLES     | 10000
```

---

# Phase 9 — Calculate Chart 5: OPEX Breakdown

## Goal

Show expense composition for the selected period.

## Chart title

```text
OPEX Breakdown
```

## Chart type

```text
Column chart or horizontal bar chart
```

Use horizontal bar if there are many categories.

## Scope

This is a performance/period chart.

Use:

```text
Expenses[Date] within selected period
```

## Calculation

```text
Sum Expenses[Amount] grouped by Expenses[Category]
```

## Recommended grouping

Use source categories directly in first version.

Optional later grouping:

```text
Fuel = Fuel
Repairs & Maintenance = Maintenance
Toll & Fees = Toll & Parking
Salaries & Wages = Driver + Payroll & Benefits
Office Expenses = Office/Admin
Others = all other categories
```

## Helper table shape

```text
Category | Amount
Fuel     | 10000
Driver   | 5000
```

---

# Phase 10 — Calculate Chart 6: Other Income Breakdown

## Goal

Show non-trip income composition for the selected period.

## Chart title

```text
Other Income
```

## Chart type

```text
Column chart or horizontal bar chart
```

Use horizontal bar if there are many categories.

## Scope

This is a performance/period chart.

Use:

```text
OtherIncome[Date] within selected period
```

## Calculation

```text
Sum OtherIncome[Amount] grouped by OtherIncome[Category]
```

## Helper table shape

```text
Category       | Amount
Service Income | 10000
Commission     | 5000
```

---

# Phase 11 — Dashboard_Helper output structure

## Goal

Create stable output ranges for the dashboard to read from.

## Recommended sections

### Section A — Metadata

```text
Key | Value
Viewing Label | Viewing: Jun 2026
Selected Year | 2026
Selected Month | Jun
Period Start Date | 2026-06-01
Period End Date | 2026-06-30
Dashboard End Date | 2026-06-30
Last Refreshed | timestamp
```

### Section B — KPI Summary

```text
Metric | Value | Type | Scope Label
Total Trips | x | Count | Selected Period
Own Truck Trips | x | Count | Selected Period
Subcon Trips | x | Count | Selected Period
Total Revenue | x | Currency | Selected Period
Total Cost | x | Currency | Selected Period
Net Income | x | Currency | Selected Period
Receivables | x | Currency | As of Dashboard End Date
Payables | x | Currency | As of Dashboard End Date
Net Cash Flow | x | Currency | Selected Period
Current Balance | x | Currency | As of Dashboard End Date
```

### Section C — Trips by Month

```text
Month | Own Truck Trips | Subcon Trips | Total Trips
```

### Section D — Monthly Financial Performance

```text
Month | Total Revenue | Total Cost | Net Income
```

### Section E — Receivables Status

```text
Status | Amount
UNBILLED | x
BILLED | x
PAID | x
```

### Section F — Payables Status

```text
Status | Amount
UNPAID | x
PAID | x
```

### Section G — OPEX Breakdown

```text
Category | Amount
```

### Section H — Other Income Breakdown

```text
Category | Amount
```

---

# Phase 12 — Dashboard header and UI behavior

## Goal

Improve the dashboard UI while keeping the current overall design.

## Header behavior

Keep the modal title as-is:

```text
Executive Overview Dashboard
```

Make the internal dashboard header sticky/frozen while scrolling.

Use CSS concept:

```css
position: sticky;
top: 0;
z-index: 50;
background: solid dark navy;
border-bottom: subtle border or shadow;
```

## Header contents

The sticky header should include:

- Logo
- M-LINE LOGISTICS
- Executive Overview Dashboard
- Viewing label
- Year dropdown
- Month dropdown
- Clear button
- Refresh button

## Filter position

Keep filters on the top-right.

Recommended layout:

```text
[Logo + Title]                         Viewing: Jun 2026
                                       Year [2026] Month [Jun] [Clear] [Refresh]
```

When cleared:

```text
[Logo + Title]                         Viewing: Lifetime
                                       Year [All] Month [All] [Clear] [Refresh]
```

---

# Phase 13 — Logo handling

## Goal

Replace the text placeholder logo with the actual uploaded M-Line logo.

## Recommended method

Use a Base64 embedded data URI.

Reason:

```text
Google Apps Script HTMLService does not serve local project asset folders like a normal web app.
```

Do not use:

```text
assets/logo.png
```

## Implementation requirement

1. Find the logo image in the project assets folder.
2. Convert it to a Base64 data URI.
3. Store it in a dashboard asset constant file.

Recommended file:

```text
src/dashboard/dashboard_assets.gs
```

Example:

```js
const DASHBOARD_LOGO_DATA_URI = 'data:image/png;base64,...';
```

4. Pass it to the HTML template:

```js
template.logoDataUri = DASHBOARD_LOGO_DATA_URI;
```

5. Replace the `ML` placeholder with:

```html
<img
  src="<?= logoDataUri ?>"
  alt="M-Line Logistics Logo"
  class="h-12 w-auto max-w-40 shrink-0 object-contain"
/>
```

---

# Phase 14 — Refresh flow

## Goal

Make refresh predictable and easy to debug.

## Refresh button behavior

When Refresh is clicked:

1. Read selected Year and Month from dashboard UI.
2. Normalize filter state.
3. If Year = All, force Month = All.
4. Calculate periodStartDate, periodEndDate, and dashboardEndDate.
5. Read source tables.
6. Calculate all KPIs and chart tables in memory.
7. Write results to `Dashboard_Helper`.
8. Return calculated payload to the dialog if needed.
9. Re-render/update cards and charts.
10. Update last refreshed timestamp.

## Clear button behavior

When Clear is clicked:

1. Set Year = All.
2. Set Month = All.
3. Refresh dashboard.
4. Viewing label becomes:

```text
Viewing: Lifetime
```

---

# Phase 15 — Error handling and empty states

## Goal

Prevent the dashboard from breaking when data is missing.

## Required behavior

If no data exists for a selected period:

- KPI cards should show `0` or `₱0.00`.
- Charts should show zero rows or a clean empty state.
- No JavaScript errors should be thrown.
- Viewing label should still be correct.

## Empty status handling

If no records exist for a donut segment, return `0` for that segment.

Example:

```text
UNBILLED | 0
BILLED   | 0
PAID     | 0
```

## Division by zero

If a future metric uses percentages, use safe division.

```text
If denominator = 0, return 0.
```

---

# Phase 16 — Validation checklist

## Goal

Confirm the dashboard is calculating correctly.

## Test scenarios

### Scenario 1 — Specific month

Filter:

```text
Year = 2026
Month = Jun
```

Expected:

- KPI performance metrics show June 2026 only.
- Receivables/Payables show outstanding balance as of June 30, 2026.
- Trips by Month shows Jan–Dec 2026.
- Monthly Financial Performance shows Jan–Dec 2026.
- Viewing label says `Viewing: Jun 2026`.

### Scenario 2 — Full year

Filter:

```text
Year = 2026
Month = All
```

Expected:

- KPI performance metrics show all 2026 records up to latest available 2026 date.
- Receivables/Payables show outstanding balance as of latest available 2026 date.
- Trips by Month shows Jan–Dec 2026.
- Monthly Financial Performance shows Jan–Dec 2026.
- Viewing label says `Viewing: 2026`.

### Scenario 3 — Lifetime

Filter:

```text
Year = All
Month = All
```

Expected:

- KPI performance metrics show lifetime totals.
- Receivables/Payables show latest outstanding balance.
- Trips chart shows lifetime monthly buckets.
- Financial chart shows lifetime monthly buckets.
- Viewing label says `Viewing: Lifetime`.

### Scenario 4 — Invalid filter state

Filter:

```text
Year = All
Month = Jun
```

Expected:

- System forces Month = All.
- Viewing label says `Viewing: Lifetime`.
- No error occurs.

---

# Final Architecture Summary

```text
Apps Script code = calculation engine
Dashboard_Helper = output/cache layer
Dashboard HTML = display layer
Charts = visual layer based on helper/output data
```

## Final financial model

```text
Trip Revenue = grossEarnings = Trip Earnings + Fuel Subsidy
Other Income = OtherIncome[Amount]
Total Revenue = Trip Revenue + Other Income
Subcon Cost = Total Subcon Earnings for subcon trips
Expenses = Expenses[Amount]
Total Cost = Subcon Cost + Expenses
Net Income = Total Revenue - Total Cost
```

## Final balance model

```text
Receivables = UNBILLED + BILLED gross earnings as of dashboardEndDate
Payables = UNPAID subcon earnings as of dashboardEndDate
Current Balance = Opening Balance + cash in up to dashboardEndDate - cash out up to dashboardEndDate
```
